import { useEffect, useState } from "react";

const initialUsers = ["Rogier", "Aya", "Miki", "Duco", "Celesta"].map((name) => ({
  name,
  keutels: 10,
}));

export default function KeutelbankApp() {
  const [users, setUsers] = useState(() => {
    const saved = localStorage.getItem("keutelbank-users");
    return saved ? JSON.parse(saved) : initialUsers;
  });

  const [haaler, setHaaler] = useState("");
  const [ontvangers, setOntvangers] = useState([]);

  useEffect(() => {
    localStorage.setItem("keutelbank-users", JSON.stringify(users));
  }, [users]);

  const toggleOntvanger = (name) => {
    setOntvangers((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    );
  };

  const doeRondje = () => {
    if (!haaler || ontvangers.length === 0) return;
    setUsers((prev) =>
      prev.map((u) => {
        if (ontvangers.includes(u.name)) {
          return { ...u, keutels: u.keutels - 1 };
        }
        return u;
      })
    );
    setHaaler("");
    setOntvangers([]);
  };

  const reset = () => {
    setUsers(initialUsers);
  };

  return (
    <div className="p-4 max-w-md mx-auto text-center">
      <h1 className="text-3xl font-bold mb-4">💩 KeutelBank Pinkpop 💗</h1>

      <div className="grid grid-cols-2 gap-2 mb-6">
        {users.map((u) => (
          <div
            key={u.name}
            className="bg-pink-100 rounded-xl p-2 shadow text-lg flex justify-between"
          >
            <span>{u.name}</span>
            <span>{u.keutels} 💩</span>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-semibold mb-2">Wie haalt?</h2>
      <select
        value={haaler}
        onChange={(e) => setHaaler(e.target.value)}
        className="mb-4 p-2 w-full rounded border"
      >
        <option value="">-- Kies iemand --</option>
        {users.map((u) => (
          <option key={u.name} value={u.name}>
            {u.name}
          </option>
        ))}
      </select>

      <h2 className="text-xl font-semibold mb-2">Voor wie is het rondje?</h2>
      <div className="grid grid-cols-2 gap-2 mb-4">
        {users.map((u) => (
          <label
            key={u.name}
            className={\`p-2 rounded border cursor-pointer \${ontvangers.includes(u.name) ? "bg-pink-300" : "bg-white"}\`}
          >
            <input
              type="checkbox"
              className="mr-2"
              checked={ontvangers.includes(u.name)}
              onChange={() => toggleOntvanger(u.name)}
            />
            {u.name}
          </label>
        ))}
      </div>

      <button
        onClick={doeRondje}
        className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded mb-2"
      >
        Rondje gedaan 🍻
      </button>

      <button
        onClick={reset}
        className="text-sm text-gray-500 underline mt-2"
      >
        Reset alles
      </button>
    </div>
  );
}
